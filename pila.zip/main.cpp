/************************************************************
Autore: Vrijoni Fabio
Programma: Pila.ccp
Data: 15 Gennaio 2021
Ide:Gdb Online
*************************************************************/
#include <iostream>
#include <string>
using namespace std;

class Pila {
    public:
    string dati[100];
    int top=0;
    
    void push(string elemento){
        dati[top]=elemento;
        top++;
    }
    
    string pop(){
        if (top==0){
            cout <<"Errore:Pop su una pila vuota"<<endl;
            return "";
        }
        top--;
        return dati[top];
    }
};

int main()
{
    Pila p;
    
    p.push("prima stringa");
    p.push("seconda stringa");
    
    for (int i=0; i<50; i++){
        string s="strings numero";
        s.append(std::to_string(i));
        p.push(s);
    }
    
    cout<<p.pop()<<endl;
    cout<<p.pop()<<endl;
    cout<<p.pop()<<endl;
    cout<<"fine programma"<<endl;
    
    return 0;
}