/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <string>
#include <iostream>
using namespace std;

    void stampa_vettore (int v[], int l ) {
        for (int i=0; i<3; i++) {
            cout <<v[i]<< endl;
        }
    }

int main () {
    int vett[3] = { 22, 33, 55};
    stampa_vettore (vett, 2);
    vett[1]= 67; // sostituisco la casella il numero della casella 1 con 67
    stampa_vettore (vett, 2); // rispetto il primo vettore abbiamo l'1 cambiato
    return 0;
}