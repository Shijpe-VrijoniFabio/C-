/*
 * BattleShipeOne - Una battaglia navale contro il computer
 *Author: Fabio Vrijoni
 *Date: 4 Dicembre 2020
 *Help sui codici nella mappa: 0-empty, 1-ship, 2-bomb, 3-strike
*/


#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;


void initialize (int v[], int l) {
    for (int i=0; i<l; i++) v[i]=0;
}

void show(int v[],int l) {
    for (int i=0; i<l; i++) {
        switch(v[i]) {
            case 0:
            cout<<"0 "<<endl;
            break;
            
            case 1:
            cout<<"x "<<endl;
            break;
            
            case 2:
            cout<<"- "<<endl;
            break;
            
            case 3:
            cout<<"* "<<endl;
            break;
        }
    cout<<endl;

}
void arrange (int v[],int l) {
    srand( time(NULL) );
    int n =rand() % (l-1);
    v[n] = l;
    v[n+1] = l;
}
void launch (int v[],int l) {
    int p=-1;
    while (p<0 || p>=1) {
        cout<< "inserire le cordinate in cui sganciare la bomba (0..." << l-1 << ") : ";
        cin >> p;
    }
    if (v[p]==0) v [p]=2;
    if (v[p]==1) v [p]=3;
    
}
bool weWon(int v[], int l) {
    for (int i=0; i<l; i++) {
        if (v[i]==1) return false;
    }
    return true;
}

int main()
{
    const int maplenght = 10;
    int map[maplenght];
    initialize(map, maplenght);
    arrange(map, maplenght);
    show (map, maplenght);
    while ( true ) {
        launch(map, maplenght);
        show(map, maplenght);
        if(weWon(map,maplenght)) {
            cout<<"hai vinto!"<<endl;
            break;
        }
    }
    return 0;
}


