/******************************************************************************

Autore: Vrijoni Fabio
Data: 05/02/21
Programma: Lista usando una classe
Eseguito su: Gdb online (funzionante)

*******************************************************************************/
#include <ctime>
#include <iostream>
#include <cstdlib>
using namespace std;


class Lista{
    private:
    string *dati;
    
    int l;
    int top=0;
    public:
    
    Lista(int lunghezza){
        
        l=lunghezza;
        dati=new string[l];
        }
        
        
    int len(){ return l;}
    string get(int x){return dati [x];}
    void add (string lv){
      if(top<100){
          dati[top]=lv;
          top++;
      }
        
    }
    string read(int x){
        return dati[x];
    }
    
    
    void print (){
        for(int x=0; x<l; x++){
            cout<<read(x)<<endl;
        }
    }
    
    string genera(){
        
        string y;
        int b=(rand()%20)+1;
        for(int x=0; x<b; x++){
            y=y+"*";
        }
        return y;
    }
};

int main()
{   
    Lista lv(100);
    for (int x=0; x<100; x++){
        
           lv.add(lv.genera());
    }
    lv.print();
    return 0;
}