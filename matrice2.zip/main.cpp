/*
 *HelloWorldMatrix.cpp
 *Esempi d'uso delle motrici
 *Autore: Vrijoni Fabio
 * Date: Dicembre 2020
*/

#include <iostream>
#include <string>
using namespace std;


void riempiMatrice( int matrice[5][5], int nrighe, int ncolonne, int valore ) {
     for (int r=0; r<nrighe; r++) {
         for (int c=0; c<ncolonne; c++) {
              matrice[r][c] = valore;
         } 
    }
}
    

int main () {
   int m[5][5];
   riempiMatrice( m, 5, 5, 33);
    
    for (int r=0; r<5; r++) {
         for (int c=0; c<5; c++) {
             cout << m[r][c] << " - ";
         } 
    }
       
    
    
    return 0;
    
}
/* diagonale motrice 10x10

